package prototype;

import java.util.List;

public class JPAPrototypeTest {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		
		System.setProperty("user", "sa");
		System.setProperty("password", "");
		
		// First unit of work (starts session)
		EntityManagerUtil.beginTransaction();
		Message message = new Message("Hello World");
		EntityManagerUtil.currentEntityManager().persist(message);
		Long msgId = message.getId();
		System.out.println("Message id of persisted object = " + msgId);

		EntityManagerUtil.commitTransaction();
		
		// Second unit of work
		EntityManagerUtil.beginTransaction();
		List<Message> messages = EntityManagerUtil.currentEntityManager().createQuery(
			"select m from Message m order by m.text asc").getResultList();
		System.out.println( messages.size() + " message(s) found:" );
		for ( Message loadedMsg : messages ) {
			System.out.println( loadedMsg.getText() );
		}
		EntityManagerUtil.commitTransaction();
		
//		 Third unit of work
		EntityManagerUtil.beginTransaction();
//		 msgId holds the identifier value of the first message
		message = (Message) EntityManagerUtil.currentEntityManager().find(
			Message.class, msgId );
		message.setText( "Greetings Earthling" );
		message.setNextMessage(
		new Message( "Take me to your leader (please)" )
		);

		EntityManagerUtil.commitTransaction();

		// Fourth unit of work
		EntityManagerUtil.beginTransaction();
		messages = EntityManagerUtil.currentEntityManager().createQuery(
			"select m from Message m order by m.text asc").getResultList();
		System.out.println( messages.size() + " message(s) found:" );
		for ( Message loadedMsg : messages ) {
			System.out.println( loadedMsg.getText() );
		}
		EntityManagerUtil.commitTransaction();

		EntityManagerUtil.closeEntityManager();
		
	}
}
