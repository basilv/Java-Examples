package prototype;

import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

@MappedSuperclass
public class BaseDomainObject implements Auditable {

	@Column(name = "CREATE_USER_ID")
	private String createUserId;
	
	@Column(name = "UPDATE_USER_ID")
	private String updateUserId;
	
	@Column(name = "CREATE_TIMESTAMP")
	private Timestamp createTimestamp;
	
	@Column(name = "UPDATE_TIMESTAMP")
	private Timestamp updateTimestamp;

	
	/* (non-Javadoc)
	 * @see prototype.Auditable#getCreateTimestamp()
	 */
	public Timestamp getCreateTimestamp() {
		return createTimestamp;
	}

	/* (non-Javadoc)
	 * @see prototype.Auditable#setCreateTimestamp(java.sql.Timestamp)
	 */
	public void setCreateTimestamp(Timestamp createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	/* (non-Javadoc)
	 * @see prototype.Auditable#getCreateUserId()
	 */
	public String getCreateUserId() {
		return createUserId;
	}

	/* (non-Javadoc)
	 * @see prototype.Auditable#setCreateUserId(java.lang.String)
	 */
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	/* (non-Javadoc)
	 * @see prototype.Auditable#getUpdateTimestamp()
	 */
	public Timestamp getUpdateTimestamp() {
		return updateTimestamp;
	}

	/* (non-Javadoc)
	 * @see prototype.Auditable#setUpdateTimestamp(java.sql.Timestamp)
	 */
	public void setUpdateTimestamp(Timestamp updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	/* (non-Javadoc)
	 * @see prototype.Auditable#getUpdateUserId()
	 */
	public String getUpdateUserId() {
		return updateUserId;
	}

	/* (non-Javadoc)
	 * @see prototype.Auditable#setUpdateUserId(java.lang.String)
	 */
	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	
}
