package prototype;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

/**
 * <code>HibernateUtil</code> class is a utility class which could be used to
 * get the hibernate session and to begin, commit and rollback the transaction
 * as well.
 * 
 */
public class HibernateUtil {

	private static SessionFactory sessionFactory;

	public static final ThreadLocal<Session> threadSession = new ThreadLocal<Session>();

	public static final ThreadLocal<Transaction> threadTransaction = new ThreadLocal<Transaction>();

	static {
		try {
			// Create the SessionFactory
			sessionFactory = new AnnotationConfiguration()
				.configure("prototype/hibernate.cfg.xml")
				.buildSessionFactory();
		} catch (Throwable exception) {	
			throw new RuntimeException("Error creating the Hibernate SessionFactory.", exception);
		}
	}
	
	/**
	 * Get the current session. This method will open the session.
	 * @return
	 * @throws HibernateException
	 */
	public static Session currentSession() {
		Session session = threadSession.get();
		// Open a new Session, if this Thread has none yet
		if (session == null) {
			session = sessionFactory.openSession(new AuditInterceptor());
			threadSession.set(session);
		}
		return session;
	}

	
	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	
	/**
	 * Close the opened current session 
	 * @throws HibernateException
	 */
	public static void closeSession() {
		Session session = threadSession.get();
		threadSession.set(null);
		if (session != null)
			session.close();
	}

	/**
	 * Begin transaction on current session.
	 */
	public static Transaction beginTransaction() {
		Transaction transaction = threadTransaction.get();
		if (transaction == null) {
			transaction = currentSession().beginTransaction();
			threadTransaction.set(transaction);
		}
		
		return transaction;
	}

	/**
	 * Commit the transaction associated with current session. 
	 * if an exception occur during the commit process, this method will call the rollback
	 */
	public static void commitTransaction() {
		Transaction transaction = threadTransaction.get();
		try {
			if (transaction != null && !transaction.wasCommitted()
					&& !transaction.wasRolledBack())
				transaction.commit();
			threadTransaction.set(null);
		} catch (HibernateException exception) {
			rollbackTransaction();
			throw exception;
		}finally {
			closeSession();
		}
	}

	
	/**
	 * Rollback the transaction and close the session at the end.
	 */
	public static void rollbackTransaction() {
		Transaction transaction = threadTransaction.get();
		threadTransaction.set(null);
		try {
			if (transaction != null && !transaction.wasCommitted()
					&& !transaction.wasRolledBack()) {
				transaction.rollback();
			}
		} finally {
			closeSession();
		}

	}
}
