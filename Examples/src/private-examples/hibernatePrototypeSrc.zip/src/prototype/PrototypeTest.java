package prototype;

import java.util.List;

import org.hibernate.LockMode;

import junit.framework.TestCase;

public class PrototypeTest extends TestCase {

	@Override
	protected void setUp() {
		
		System.setProperty("user", "sa");
		System.setProperty("password", "");
		
	}
	
	
	
	@Override
	protected void tearDown() {
		HibernateUtil.closeSession();
	}



	@SuppressWarnings("unchecked")
	public void testBasicBehavior() {
		
		// First unit of work (starts session)
		HibernateUtil.beginTransaction();

		// Delete all existing messages
		List<Message> messages = HibernateUtil.currentSession().createQuery("from Message m order by m.text asc").list();
		for (Message message : messages) {
			HibernateUtil.currentSession().delete(message);
		}
		
		Message message = new Message("Hello World");
		Long messageId = (Long) HibernateUtil.currentSession().save(message);
		assertNotNull(messageId);
		
		HibernateUtil.commitTransaction();
		
		// Second unit of work
		HibernateUtil.beginTransaction();
		messages = HibernateUtil.currentSession().createQuery("from Message m order by m.text asc").list();
		assertEquals(messages.size(), 1);
		HibernateUtil.commitTransaction();
		
//		 Third unit of work
		HibernateUtil.beginTransaction();
		message = (Message) HibernateUtil.currentSession().get( Message.class, messageId );
		assertNotNull(message);
		assertEquals(message.getId(), messageId);
		message.setText( "Greetings Earthling" );
		message.setNextMessage(
		new Message( "Take me to your leader (please)" )
		);

		HibernateUtil.commitTransaction();

		// Fourth unit of work
		HibernateUtil.beginTransaction();
		messages = HibernateUtil.currentSession().createQuery("from Message m order by m.text asc").list();
		assertEquals(messages.size(), 2);
		HibernateUtil.commitTransaction();

	}


	@SuppressWarnings("unchecked")
	public void testBaseDomainObjectFields() {

		// First unit of work (starts session)
		HibernateUtil.beginTransaction();

		// Delete all existing messages
		List<Message> messages = HibernateUtil.currentSession().createQuery("from Message m order by m.text asc").list();
		for (Message message : messages) {
			HibernateUtil.currentSession().delete(message);
		}
		
		Message newMessage = new Message("Hello World");
		String user = "testUpdate";
		newMessage.setUpdateUserId(user);
		Long messageId = (Long) HibernateUtil.currentSession().save(newMessage);
		assertNotNull(messageId);

		HibernateUtil.commitTransaction();

		HibernateUtil.closeSession();
		
		Message existingMessage = (Message) HibernateUtil.currentSession().get(Message.class, messageId);
		assertEquals(user, existingMessage.getUpdateUserId());
		
	}

	
	@SuppressWarnings("unchecked")
	public void testUseofAuditInterceptor() {
		
		String user = "testUser";
		AuditInterceptor.setUserForCurrentThread(user);
		
		// First unit of work (starts session)
		HibernateUtil.beginTransaction();

		// Delete all existing messages
		List<Message> messages = HibernateUtil.currentSession().createQuery("from Message m order by m.text asc").list();
		for (Message message : messages) {
			HibernateUtil.currentSession().delete(message);
		}
		
		Message newMessage = new Message("Hello World");
		Long messageId = (Long) HibernateUtil.currentSession().save(newMessage);
		assertNotNull(messageId);
		// Audit interceptor should have set the create fields during the save
		assertNotNull(newMessage.getCreateUserId());
		assertNotNull(newMessage.getCreateTimestamp());

		HibernateUtil.commitTransaction();

		HibernateUtil.currentSession().clear();
		HibernateUtil.closeSession();
		
		HibernateUtil.beginTransaction();
		Message existingMessage = (Message) HibernateUtil.currentSession().get(Message.class, messageId);
		assertEquals(user, existingMessage.getCreateUserId());
		assertNotNull(existingMessage.getCreateTimestamp());

		existingMessage.setText( "Greetings Earthling" );
		long timeBeforeFlush = System.currentTimeMillis();
		HibernateUtil.currentSession().flush();
		
		assertEquals(user, existingMessage.getUpdateUserId());
		assertNotNull(existingMessage.getUpdateTimestamp());
		assertTrue(existingMessage.getUpdateTimestamp().getTime() >= timeBeforeFlush);

		HibernateUtil.commitTransaction();
		
	}

	@SuppressWarnings("unchecked")
	public void testDetachedObjectsNotAutomaticallyDirtyWhenReattached() {

		String user = "testUser";
		AuditInterceptor.setUserForCurrentThread(user);
		
		// First unit of work (starts session)
		HibernateUtil.beginTransaction();

		// Delete all existing messages
		List<Message> messages = HibernateUtil.currentSession().createQuery("from Message m order by m.text asc").list();
		for (Message message : messages) {
			HibernateUtil.currentSession().delete(message);
		}
		
		Message newMessage = new Message("Hello World");
		Long messageId = (Long) HibernateUtil.currentSession().save(newMessage);
		assertNotNull(messageId);
		// Audit interceptor should have set the create fields during the save
		assertNotNull(newMessage.getCreateUserId());
		assertNotNull(newMessage.getCreateTimestamp());

		HibernateUtil.commitTransaction();

		HibernateUtil.currentSession().clear();
		HibernateUtil.closeSession();
		
		HibernateUtil.beginTransaction();
		
		Message existingMessage = (Message) HibernateUtil.currentSession().get(Message.class, messageId);
		assertEquals(user, existingMessage.getCreateUserId());
		assertNotNull(existingMessage.getCreateTimestamp());

		// Don't change existing message.
		
		HibernateUtil.currentSession().flush();
		assertNull(existingMessage.getUpdateTimestamp());
		assertNull(existingMessage.getUpdateUserId());

		HibernateUtil.commitTransaction();
		HibernateUtil.currentSession().clear();
		HibernateUtil.closeSession();
		
		HibernateUtil.beginTransaction();

		// Attaching a detached instance with update always causes the object to be written to the database
		// unless select-before-update=true for the entity.
//		HibernateUtil.currentSession().update(existingMessage);
		
		// Attaching a modified detached instance using lock with select-before-update=false or true
		// causes the modifications to be lost since Hibernate doesn't know about them.
//		existingMessage.setText("new text");
//		HibernateUtil.currentSession().lock(existingMessage, LockMode.NONE);

		// Attaching a detached instance using lock and then modifying it afterward
		// does work (with select-before-update=false).
		HibernateUtil.currentSession().lock(existingMessage, LockMode.NONE);
		HibernateUtil.currentSession().flush();
		assertNull(existingMessage.getUpdateTimestamp());
		assertNull(existingMessage.getUpdateUserId());

		existingMessage.setText("new text");
		HibernateUtil.currentSession().flush();
		assertNotNull(existingMessage.getUpdateTimestamp());
		assertNotNull(existingMessage.getUpdateUserId());

		HibernateUtil.commitTransaction();
		
	}
}
