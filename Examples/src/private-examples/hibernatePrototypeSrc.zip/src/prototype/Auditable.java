package prototype;

import java.sql.Timestamp;

public interface Auditable {

	public abstract Timestamp getCreateTimestamp();

	public abstract void setCreateTimestamp(Timestamp createTimestamp);

	public abstract String getCreateUserId();

	public abstract void setCreateUserId(String createUserId);

	public abstract Timestamp getUpdateTimestamp();

	public abstract void setUpdateTimestamp(Timestamp updateTimestamp);

	public abstract String getUpdateUserId();

	public abstract void setUpdateUserId(String updateUserId);

}