package prototype;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.HibernateException;

/**
 * <code>HibernateUtil</code> class is a utility class which could be used to
 * get the hibernate session and to begin, commit and rollback the transaction
 * as well.
 * 
 */
public class EntityManagerUtil {

	private static EntityManagerFactory entityManagerFactory;
	
	public static final ThreadLocal<EntityManager> threadEntityManager = 
		new ThreadLocal<EntityManager>();

	public static final ThreadLocal<EntityTransaction> threadTransaction = 
		new ThreadLocal<EntityTransaction>();

	static {
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("nms");
		} catch (Throwable exception) {	
			throw new RuntimeException("Error creating the Entity Manager Factory.", exception);
		}
	}
	
	/**
	 * Get the current entity manager associated with this thread, creating one
	 * if necessary.
	 * @return
	 * @throws HibernateException
	 */
	public static EntityManager currentEntityManager() {
		EntityManager entityManager = threadEntityManager.get();
		if (entityManager == null) {
			entityManager = entityManagerFactory.createEntityManager();
			threadEntityManager.set(entityManager);
		}
		return entityManager;
	}

	public static void closeEntityManager() {
		EntityManager entityManager = threadEntityManager.get();
		if (entityManager != null) {
			entityManager.close();
			threadEntityManager.set(null);
		}
	}

	public static EntityTransaction beginTransaction() {
		EntityTransaction transaction = threadTransaction.get();
		if (transaction == null) {
			transaction = currentEntityManager().getTransaction();
			transaction.begin();
			threadTransaction.set(transaction);
		}
		return transaction;
	}

	public static void commitTransaction() {
		EntityTransaction transaction = threadTransaction.get();
		if (transaction != null) {
			// TODO: Should we commit if transaction.getRollbackOnly() == true?
			transaction.commit();
			// TODO: Catch exception and rollback if a problem
			threadTransaction.set(null);
		}
	}

	
	public static void rollbackTransaction() {
		EntityTransaction transaction = threadTransaction.get();
		if (transaction != null) {
			transaction.rollback();
			threadTransaction.set(null);
		}
	}

}
