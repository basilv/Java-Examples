package prototype;

import java.io.Serializable;
import java.sql.Timestamp;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

public class AuditInterceptor extends EmptyInterceptor {

	private static ThreadLocal<String> userPerThread = new ThreadLocal<String>();
	
	public static void setUserForCurrentThread(String user) {
		userPerThread.set(user);
	}
	
    public boolean onFlushDirty(Object entity,
                                Serializable id,
                                Object[] currentState,
                                Object[] previousState,
                                String[] propertyNames,
                                Type[] types) {

    	boolean changed = false;
    	
        if ( entity instanceof Auditable ) {
            for ( int i=0; i < propertyNames.length; i++ ) {
                if ( "updateTimestamp".equals( propertyNames[i] ) ) {
                    currentState[i] = new Timestamp(System.currentTimeMillis());
                    changed = true;
                }
                if ( "updateUserId".equals( propertyNames[i] ) ) {
                	currentState[i] = userPerThread.get();
                	changed = true;
                }
            }
        }
        return changed;
    }

    public boolean onSave(Object entity,
                          Serializable id,
                          Object[] currentState,
                          String[] propertyNames,
                          Type[] types) {

    	boolean changed = false;
    	
        if ( entity instanceof Auditable ) {
            for ( int i=0; i < propertyNames.length; i++ ) {
                if ( "createTimestamp".equals( propertyNames[i] ) ) {
                    currentState[i] = new Timestamp(System.currentTimeMillis());
                    changed = true;
                }
                if ( "createUserId".equals( propertyNames[i] ) ) {
                	currentState[i] = userPerThread.get();
                	changed = true;
                }
            }
        }
        return changed;

    }

}